import React, { useEffect, useState } from "react";
import { fetchProductsByMerchantEmail } from "../api/merchant";
import { addProduct } from "../api/admin";
import { getAuthToken } from "../api/_auth";

export default function MerchantProducts() {
    const [products, setProducts] = useState([]);
    const [err, setErr] = useState("");
    const [showForm, setShowForm] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [form, setForm] = useState({
        productType: "",
        productName: "",
        category: "",
        image: "",
        price: "",
        description: "",
        discount: "",
        stock: "",
    });
    const email = localStorage.getItem("email") || "";
    const token = getAuthToken();

    useEffect(() => {
        const run = async () => {
            setErr("");
            try {
                const data = await fetchProductsByMerchantEmail(email, token);
                setProducts(Array.isArray(data) ? data : []);
            } catch (e) {
                setErr(e?.message || "Failed to load products");
            }
        };
        run();
    }, [email, token]);

    const onChange = (e) => {
        const { name, value } = e.target;
        setForm((f) => ({ ...f, [name]: value }));
    };

    const resetForm = () => {
        setForm({
            productType: "",
            productName: "",
            category: "",
            image: "",
            price: "",
            description: "",
            discount: "",
            stock: "",
        });
    };

    const onAddProduct = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        setErr("");
        try {
            // Basic validation
            if (!form.productName || !form.category || !form.price || !form.stock) {
                throw new Error("Please fill product name, category, price and stock.");
            }
            // Build payload with merchant email automatically injected
            const payload = {
                ...form,
                price: Number(form.price),
                discount: form.discount === "" ? 0 : Number(form.discount),
                stock: Number(form.stock),
                merchantEmail: email, // <- auto-attach signed-in merchant email
            };
            await addProduct(payload, token);
            resetForm();
            setShowForm(false);
            // ... existing code ...
            const data = await fetchProductsByMerchantEmail(email, token);
            setProducts(Array.isArray(data) ? data : []);
        } catch (e) {
            setErr(e?.message || "Failed to add product");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="p-4 mt-16 max-w-6xl mx-auto">
            <div className="mb-4 flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">My Products</h1>
                    <p className="text-sm text-gray-600">Signed in as {email}</p>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={() => setShowForm((v) => !v)}
                        className="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                        {showForm ? "Close" : "Add Product"}
                    </button>
                </div>
            </div>

            {showForm && (
                <form onSubmit={onAddProduct} className="bg-white rounded-xl shadow p-4 mb-6 grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input
                        name="productType"
                        value={form.productType}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Product Type"
                    />
                    <input
                        name="productName"
                        value={form.productName}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Product Name"
                        required
                    />
                    <select
                        name="category"
                        value={form.category}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        required
                    >
                        <option value="">Select Category</option>
                        <option>Electronics</option>
                        <option>Clothing</option>
                        <option>Books</option>
                        <option>Home</option>
                    </select>
                    <input
                        name="image"
                        value={form.image}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Image URL"
                    />
                    <input
                        name="price"
                        type="number"
                        value={form.price}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Price"
                        required
                    />
                    <input
                        name="discount"
                        type="number"
                        value={form.discount}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Discount (%)"
                    />
                    <input
                        name="stock"
                        type="number"
                        value={form.stock}
                        onChange={onChange}
                        className="border rounded px-3 py-2"
                        placeholder="Stock Quantity"
                        required
                    />
                    <textarea
                        name="description"
                        value={form.description}
                        onChange={onChange}
                        className="border rounded px-3 py-2 md:col-span-2"
                        rows={3}
                        placeholder="Description"
                    />
                    {/* No merchantEmail field here – it is auto-attached from the signed-in user */}
                    <div className="md:col-span-2 flex gap-2 justify-end">
                        <button
                            type="button"
                            className="px-4 py-2 rounded border"
                            onClick={() => {
                                resetForm();
                                setShowForm(false);
                            }}
                            disabled={submitting}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={submitting}
                            className={`px-4 py-2 rounded text-white ${submitting ? "bg-gray-400" : "bg-blue-600 hover:bg-blue-700"}`}
                        >
                            {submitting ? "Saving…" : "Save Product"}
                        </button>
                    </div>
                </form>
            )}

            {err ? (
                <div className="p-3 bg-red-50 text-red-700 border border-red-200 rounded">{err}</div>
            ) : products.length === 0 ? (
                <p className="text-gray-500">No products found.</p>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {products.map((p) => (
                        <div key={p.productId} className="bg-white p-4 rounded-xl shadow hover:shadow-md transition">
                            <img src={p.image} alt={p.productName} className="w-full h-40 object-cover rounded mb-3" />
                            <h3 className="font-semibold">{p.productName}</h3>
                            <p className="text-sm text-gray-600 line-clamp-2">{p.description}</p>
                            <div className="mt-2 text-sm">
                                <span className="font-semibold">₹{p.price}</span>
                                <span className="ml-2 text-green-700">{p.discount}% off</span>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">Stock: {p.stock}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}