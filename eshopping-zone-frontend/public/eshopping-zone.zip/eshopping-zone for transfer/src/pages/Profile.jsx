// import React, { useEffect, useState } from "react";
// import { fetchUserById, fetchOrdersByUser } from "../api/user";
//
// export default function Profile() {
//   const [user, setUser] = useState(null);
//   const [orders, setOrders] = useState([]);
//
//   useEffect(() => {
//     const userId = localStorage.getItem("customerId");
//
//     if (!userId) {
//       console.error("User ID not found in localStorage");
//       return;
//     }
//
//     fetchUserById(userId)
//       .then((data) => setUser(data))
//       .catch((err) => console.error("Failed to fetch user:", err));
//
//     fetchOrdersByUser(userId)
//       .then((data) => setOrders(data))
//       .catch((err) => console.error("Failed to fetch orders:", err));
//   }, []);
//
//   if (!user) return <p className="text-center mt-10">Loading profile...</p>;
//
//   return (
//     <div className="max-w-4xl mx-auto mt-16 p-6">
//       <div className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center">
//         <img
//           src={user.image || "https://tse3.mm.bing.net/th/id/OIP.EwG6x9w6RngqsKrPJYxULAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3"}
//           alt="Profile"
//           className="w-32 h-32 object-cover rounded-full border-4 border-blue-500 mb-4"
//         />
//         <h2 className="text-2xl font-bold text-blue-700 mb-1">{user.fullName}</h2>
//         <p className="text-gray-600">{user.emailId}</p>
//         <p className="text-gray-600">Mobile: {user.mobileNumber}</p>
//         <p className="text-gray-600">DOB: {user.dateOfBirth}</p>
//         <p className="text-gray-600">Gender: {user.gender}</p>
//         <p className="text-gray-500 italic mt-2 text-center">{user.about}</p>
//       </div>
//
//       <hr className="my-8" />
//
//       <h3 className="text-xl font-semibold mb-4 text-blue-700">Your Orders</h3>
//       {orders.length === 0 ? (
//         <p className="text-gray-500">No orders found.</p>
//       ) : (
//         <ul className="space-y-4">
//           {orders.map((order) => (
//             <li key={order.orderId} className="border p-4 rounded bg-white shadow-sm">
//               <p><strong>Order ID:</strong> {order.orderId}</p>
//               <p><strong>Date:</strong> {order.orderDate}</p>
//               <p><strong>Status:</strong> {order.orderStatus}</p>
//               <p><strong>Amount Paid:</strong> ₹{order.amountPaid}</p>
//               <p><strong>Payment Mode:</strong> {order.modeOfPayment}</p>
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// }

import React, { useEffect, useState } from "react";
import { fetchUserById, fetchOrdersByUser, updateUserProfile, fetchUserByEmail } from "../api/user";
import { useNavigate } from "react-router-dom";

export default function Profile() {
    const [user, setUser] = useState(null);
    const [orders, setOrders] = useState([]);
    const [editing, setEditing] = useState(false);
    const [saving, setSaving] = useState(false);
    const [form, setForm] = useState(null);
    const [msg, setMsg] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const email = localStorage.getItem("email");
        if (!email) {
            // No identity available => ask user to login
            navigate("/login", { replace: true });
            return;
        }

        const load = async () => {
            try {
                // Fetch the user by email (authoritative identity from backend)
                const u = await fetchUserByEmail(email);
                setUser(u);

                // Keep customerId in localStorage synchronized (optional convenience)
                const id = u?.userId ?? u?.id;
                if (id && /^\d+$/.test(String(id))) {
                    localStorage.setItem("customerId", String(id));
                }

                // Prepare edit form
                setForm({
                    fullName: u.fullName || "",
                    emailId: u.emailId || "",
                    mobileNumber: u.mobileNumber || "",
                    dateOfBirth: u.dateOfBirth || "",
                    gender: u.gender || "",
                    about: u.about || "",
                    image: u.image || "",
                });

                // Fetch orders using the id resolved from backend
                if (id) {
                    const ods = await fetchOrdersByUser(id);
                    setOrders(Array.isArray(ods) ? ods : []);
                }
            } catch (e) {
                // If unauthorized, redirect to login
                const m = String(e?.message || "");
                if (m.toLowerCase().includes("unauthorized") || m.includes("401")) {
                    navigate("/login", { replace: true });
                } else {
                    console.error("Failed to load profile:", e);
                }
            }
        };

        load();
    }, [navigate]);

    const onSave = async () => {
        if (!form || !user) return;
        setSaving(true);
        setMsg("");
        try {
            const uid = user.userId ?? user.id;
            await updateUserProfile(uid, { ...user, ...form });
            setUser((u) => ({ ...u, ...form }));
            setEditing(false);
            setMsg("Profile updated successfully.");
        } catch (e) {
            setMsg(e?.message || "Failed to update profile.");
        } finally {
            setSaving(false);
        }
    };

    if (!user) return <p className="text-center mt-10">Loading profile...</p>;

    return (
        <div className="max-w-4xl mx-auto mt-16 p-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
                <div className="flex flex-col items-center md:flex-row md:items-start gap-6">
                    <img
                        src={user.image || "https://tse3.mm.bing.net/th/id/OIP.EwG6x9w6RngqsKrPJYxULAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3"}
                        alt="Profile"
                        className="w-32 h-32 object-cover rounded-full border-4 border-blue-500"
                        onError={(e) => (e.currentTarget.src = "https://tse3.mm.bing.net/th/id/OIP.EwG6x9w6RngqsKrPJYxULAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3")}
                    />

                    {!editing ? (
                        <div className="flex-1">
                            <div className="flex items-center gap-2">
                                <h2 className="text-2xl font-bold text-blue-700">{user.fullName}</h2>
                                <button
                                    className="px-3 py-1 rounded text-sm bg-blue-600 text-white hover:bg-blue-700"
                                    onClick={() => setEditing(true)}
                                >
                                    Edit
                                </button>
                            </div>
                            <p className="text-gray-600">{user.emailId}</p>
                            <p className="text-gray-600">Mobile: {user.mobileNumber}</p>
                            <p className="text-gray-600">DOB: {user.dateOfBirth}</p>
                            <p className="text-gray-600">Gender: {user.gender}</p>
                            <p className="text-gray-500 italic mt-2">{user.about}</p>
                        </div>
                    ) : (
                        <div className="flex-1 grid grid-cols-1 text-black md:grid-cols-2 gap-3 w-full">
                            <input
                                className="border rounded px-3 py-2"
                                value={form.fullName}
                                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                                placeholder="Full Name"
                            />
                            <input
                                className="border rounded px-3 py-2"
                                value={form.emailId}
                                onChange={(e) => setForm({ ...form, emailId: e.target.value })}
                                placeholder="Email"
                            />
                            <input
                                className="border rounded px-3 py-2"
                                value={form.mobileNumber}
                                onChange={(e) => setForm({ ...form, mobileNumber: e.target.value })}
                                placeholder="Mobile"
                            />
                            <input
                                className="border rounded px-3 py-2"
                                value={form.dateOfBirth}
                                onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })}
                                placeholder="DOB"
                            />
                            <input
                                className="border rounded px-3 py-2"
                                value={form.gender}
                                onChange={(e) => setForm({ ...form, gender: e.target.value })}
                                placeholder="Gender"
                            />
                            <input
                                className="border rounded px-3 py-2 md:col-span-2"
                                value={form.image}
                                onChange={(e) => setForm({ ...form, image: e.target.value })}
                                placeholder="Profile Image URL"
                            />
                            <textarea
                                className="border rounded px-3 py-2 md:col-span-2"
                                rows={3}
                                value={form.about}
                                onChange={(e) => setForm({ ...form, about: e.target.value })}
                                placeholder="About"
                            />
                            <div className="md:col-span-2 flex gap-2">
                                <button
                                    className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                                    onClick={() => {
                                        setEditing(false);
                                        setForm({
                                            fullName: user.fullName || "",
                                            emailId: user.emailId || "",
                                            mobileNumber: user.mobileNumber || "",
                                            dateOfBirth: user.dateOfBirth || "",
                                            gender: user.gender || "",
                                            about: user.about || "",
                                            image: user.image || "",
                                        });
                                    }}
                                >
                                    Cancel
                                </button>
                                <button
                                    className={`px-4 py-2 rounded text-white ${saving ? "bg-gray-400" : "bg-blue-600 hover:bg-blue-700"}`}
                                    onClick={onSave}
                                    disabled={saving}
                                >
                                    {saving ? "Saving…" : "Save"}
                                </button>
                            </div>
                            {msg && <p className="md:col-span-2 text-sm text-green-700">{msg}</p>}
                        </div>
                    )}
                </div>
            </div>

            <hr className="my-8" />

            <h3 className="text-xl font-semibold mb-4 text-blue-700">Your Orders</h3>
            {orders.length === 0 ? (
                <p className="text-gray-500">No orders found.</p>
            ) : (
                <ul className="space-y-4">
                    {orders.map((order) => (
                        <li key={order.orderId} className="border p-4 rounded bg-white shadow-sm">
                            <p><strong>Order ID:</strong> {order.orderId}</p>
                            <p><strong>Date:</strong> {order.orderDate}</p>
                            <p><strong>Status:</strong> {order.orderStatus}</p>
                            <p><strong>Amount Paid:</strong> ₹{order.amountPaid}</p>
                            <p><strong>Payment Mode:</strong> {order.modeOfPayment}</p>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
