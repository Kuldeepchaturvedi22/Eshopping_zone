import React, { useEffect, useState } from "react";
import { fetchAllProducts } from "../api/product";
import { useNavigate } from "react-router-dom";

export default function FeaturedProducts() {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        let mounted = true;
        const load = async () => {
            try {
                const data = await fetchAllProducts();
                if (!mounted) return;
                // Simple heuristic: highest discount first; take top 8 as “featured”
                const sorted = (Array.isArray(data) ? data : [])
                    .slice()
                    .sort((a, b) => Number(b.discount ?? 0) - Number(a.discount ?? 0))
                    .slice(0, 8);
                setItems(sorted);
            } catch {
                setItems([]);
            } finally {
                if (mounted) setLoading(false);
            }
        };
        load();
        return () => { mounted = false; };
    }, []);

    if (loading) {
        return (
            <section className="mt-10">
                <h3 className="text-xl font-semibold text-black mb-3">Featured</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[...Array(4)].map((_, i) => (
                        <div key={i} className="card-glass h-40 animate-pulse" />
                    ))}
                </div>
            </section>
        );
    }

    if (items.length === 0) return null;

    return (
        <section className="mt-10">
            <h3 className="text-xl font-semibold text-black mb-3">Featured</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-5">
                {items.map((p) => (
                    <button
                        key={p.productId}
                        onClick={() => navigate(`/product/${p.productId}`)}
                        className="text-left card-glass hover:shadow-xl"
                    >
                        <img src={p.image} alt={p.productName} className="w-full h-36 object-cover rounded-xl mb-3" />
                        <div className="px-1">
                            <div className="font-semibold text-black truncate">{p.productName}</div>
                            <div className="text-sm text-gray-700 mt-0.5">₹{p.price}</div>
                            {p.discount ? <div className="text-xs text-emerald-600">{p.discount}% OFF</div> : null}
                        </div>
                    </button>
                ))}
            </div>
        </section>
    );
}