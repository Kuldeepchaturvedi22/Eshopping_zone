import React, { useEffect, useMemo, useState, useCallback } from "react";

const TAGLINE_KEY = "site:tagline";
const BANNER_KEY = "site:banner";

export default function Hero() {
    const defaultTagline = "Shop the latest collections";
    const defaultBanners = useMemo(() => ["/banner-01.jpg", "/banner-02.jpg", "/banner-03.jpg", "/hero-bg.jpg"], []);

    // Stable random-picker so effects don't re-run endlessly
    const pickDefault = useCallback(
        () => defaultBanners[Math.floor(Math.random() * defaultBanners.length)],
        [defaultBanners]
    );

    const [tagline, setTagline] = useState(() => localStorage.getItem(TAGLINE_KEY) || defaultTagline);
    const [banner, setBanner] = useState(() => localStorage.getItem(BANNER_KEY) || pickDefault());

    useEffect(() => {
        const onUpdate = () => {
            const nextTagline = localStorage.getItem(TAGLINE_KEY) || defaultTagline;
            const stored = localStorage.getItem(BANNER_KEY);
            const nextBanner = stored || pickDefault();

            // Update only when value actually changes to avoid render loops
            setTagline((prev) => (prev === nextTagline ? prev : nextTagline));
            setBanner((prev) => (prev === nextBanner ? prev : nextBanner));
        };

        window.addEventListener("site:settings-updated", onUpdate);
        return () => window.removeEventListener("site:settings-updated", onUpdate);
    }, [pickDefault]);

    return (
        <section className="relative h-[320px] md:h-[460px] rounded-3xl overflow-hidden mt-16 group">
            <img
                src={banner}
                alt="Banner"
                className="absolute inset-0 w-full h-full object-cover scale-105 transition-transform duration-[1800ms] ease-out group-hover:scale-110"
                onError={(e) => {
                    const fallback = pickDefault();
                    if (e.currentTarget.src.endsWith(fallback)) return; // avoid loops if fallback fails too
                    e.currentTarget.src = fallback;
                }}
                fetchPriority="high"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/35 to-black/70" />

            <div className="absolute top-6 left-6 z-10 flex flex-wrap gap-2">
                <span className="px-3 py-1 text-xs font-semibold rounded-full bg-white/90 text-black shadow">New Arrivals</span>
                <span className="px-3 py-1 text-xs font-semibold rounded-full bg-emerald-500 text-white shadow">Up to 60% Off</span>
                <span className="px-3 py-1 text-xs font-semibold rounded-full bg-indigo-500 text-white shadow">Free Shipping over ₹999</span>
            </div>

            <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
                <h1 className="text-white text-3xl md:text-5xl font-extrabold tracking-tight drop-shadow-lg">
                    {tagline || defaultTagline}
                </h1>
                <p className="mt-3 text-white/90 text-sm md:text-base">
                    Discover curated styles, exclusive drops, and everyday essentials.
                </p>
                <div className="mt-6 flex gap-3">
                    <a href="/categories" className="btn-glossy">Shop Now</a>
                    <a href="/products" className="btn-glossy">Explore</a>
                </div>
            </div>
        </section>
    );
}