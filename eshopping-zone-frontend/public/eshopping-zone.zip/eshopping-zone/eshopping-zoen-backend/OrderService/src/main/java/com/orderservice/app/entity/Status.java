package com.orderservice.app.entity;

public enum Status {
 PLACED,
 SHIPPED,
 DELIVERED,
 CANCELLED,
 PENDING,
 FAILED
}
