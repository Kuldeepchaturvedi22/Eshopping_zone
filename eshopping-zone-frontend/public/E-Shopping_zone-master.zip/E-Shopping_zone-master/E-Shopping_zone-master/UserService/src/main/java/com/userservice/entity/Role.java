package com.userservice.entity;

public enum Role {
    CUSTOMER, MERCHANT, ADMIN
}
