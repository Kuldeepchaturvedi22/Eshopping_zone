package com.cartservice.app.exception;

public class CartServiceException extends RuntimeException {

    public CartServiceException(String message) {
        super(message);
    }

}

	