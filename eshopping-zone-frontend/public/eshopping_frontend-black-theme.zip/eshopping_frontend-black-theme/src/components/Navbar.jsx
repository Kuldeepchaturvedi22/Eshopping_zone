// import React, { useEffect, useRef, useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import {
//     MagnifyingGlassIcon,
//     ShoppingCartIcon,
//     UserCircleIcon,
//     XMarkIcon,
//     Bars3Icon,
// } from "@heroicons/react/24/outline";
// import { SunIcon, MoonIcon } from "@heroicons/react/24/solid";
// import { useCart } from "../context/CartContext";
// import SearchBar from "./SearchBar";
//
// export default function Navbar() {
//     const [isLoggedIn, setIsLoggedIn] = useState(false);
//     const [showMenu, setShowMenu] = useState(false);
//     const [catsOpen, setCatsOpen] = useState(false);
//     const [theme, setTheme] = useState("light");
//     const catsTimerRef = useRef(null);
//     const navigate = useNavigate();
//     const { getTotalItems } = useCart();
//
//     useEffect(() => {
//         const loggedIn = localStorage.getItem("isLoggedIn") === "true";
//         setIsLoggedIn(loggedIn);
//     }, []);
//
//     // Load + apply theme on mount
//     useEffect(() => {
//         const saved = localStorage.getItem("theme") || "light";
//         setTheme(saved);
//         document.documentElement.setAttribute("data-theme", saved);
//     }, []);
//
//     const toggleTheme = () => {
//         const next = theme === "dark" ? "light" : "light";
//         setTheme(next);
//         localStorage.setItem("theme", next);
//         document.documentElement.setAttribute("data-theme", next);
//     };
//
//     const openCats = () => {
//         if (catsTimerRef.current) clearTimeout(catsTimerRef.current);
//         setCatsOpen(true);
//     };
//     const closeCats = () => {
//         if (catsTimerRef.current) clearTimeout(catsTimerRef.current);
//         catsTimerRef.current = setTimeout(() => setCatsOpen(false), 120);
//     };
//
//     const handleLogout = () => {
//         localStorage.clear();
//         setIsLoggedIn(false);
//         navigate("/login");
//         window.location.reload();
//     };
//
//     const handleMenuClick = () => setShowMenu(false);
//     const handleCategoryClick = (category) => {
//         navigate(`/products?category=${encodeURIComponent(category)}`);
//         setShowMenu(false);
//     };
//
//     const categories = ["Electronics", "Fashion", "Home", "Books", "Toys"];
//
//     return (
//         <nav className="nav-glossy">
//             <div className="max-w-7xl mx-auto px-4 py-3 bg-gray-300 flex items-center gap-4">
//                 {/* Brand */}
//                 <Link to="/" className="flex items-center gap-2 group">
//                     <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] shadow-lg">
//                         <img src="/favicon.svg" alt="Logo" className="h-full w-full object-cover rounded-lg" />
//                     </div>
//                     <span className="text-black font-extrabold tracking-tight text-lg group-hover:opacity-90">
//             E‑Shopping Zone
//           </span>
//                 </Link>
//
//                 {/* Search */}
//                 <div className="hidden md:flex items-center flex-1 mx-6">
//                     <SearchBar />
//                 </div>
//
//                 {/* Desktop links/actions */}
//                 <ul className="ml-auto hidden md:flex gap-6 items-center">
//                     <Link to="/" className="text-white/85 hover:text-white link-underline">Home</Link>
//                     <Link to="/products" className="text-white/85 hover:text-white link-underline">Products</Link>
//
//                     {/* Categories dropdown */}
//                     <div className="relative" onMouseEnter={openCats} onMouseLeave={closeCats}>
//                         <button className="text-black hover:text-gray-800 link-underline">Categories</button>
//                         {catsOpen && (
//                             <div className="absolute bg-gray-700 text-black right-0 mt-3 w-44 rounded-2xl glass p-2 z-50">
//                                 {categories.map((cat) => (
//                                     <button
//                                         key={cat}
//                                         onClick={() => handleCategoryClick(cat)}
//                                         className="block w-full text-left px-3 py-2 rounded-lg hover:bg-gray-800 hover:text-white"
//                                     >
//                                         {cat}
//                                     </button>
//                                 ))}
//                             </div>
//                         )}
//                     </div>
//
//                      {/*Theme toggle */}
//                     <button
//                         aria-label="Toggle theme"
//                         onClick={toggleTheme}
//                         className="rounded-lg hover:bg-white/10 p-1 transition text-white"
//                         title={theme === "light" ? "Switch to light" : "Switch to dark"}
//                     >
//                         {theme === "light" ? <SunIcon className="h-6 w-6" /> : <MoonIcon className="h-6 w-6" />}
//                     </button>
//
//
//                     {/* Cart */}
//                     <Link to="/cart" className="relative">
//                         <ShoppingCartIcon className="h-6 w-6 text-white/90 hover:text-white transition" />
//                         {getTotalItems() > 0 && (
//                             <span className="absolute -top-2 -right-2 bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)] text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-lg">
//                 {getTotalItems()}
//               </span>
//                         )}
//                     </Link>
//
//                     {/* User menu */}
//                     <div className="relative">
//                         <button onClick={() => setShowMenu((v) => !v)} className="rounded-lg hover:bg-white/10 p-1 transition">
//                             <UserCircleIcon className="h-8 w-8 text-white/90 hover:text-white" />
//                         </button>
//                         {showMenu && (
//                             <div className="absolute bg-gray-700 right-0 mt-3 w-56 rounded-2xl glass p-2 z-50">
//                                 <Link to="/profile" className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white" onClick={handleMenuClick}>My Account</Link>
//                                 <Link to="/orders" className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white" onClick={handleMenuClick}>Orders</Link>
//                                 <Link to="/about" className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white" onClick={handleMenuClick}>About Us</Link>
//                                 {isLoggedIn ? (
//                                     <button onClick={handleLogout} className="block w-full text-left px-3 py-2 rounded-lg text-red-600 hover:bg-red-500/10 hover:text-red-000">
//                                         Logout
//                                     </button>
//                                 ) : (
//                                     <Link to="/login" className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/10 hover:text-white" onClick={handleMenuClick}>
//                                         Login
//                                     </Link>
//                                 )}
//                             </div>
//                         )}
//                     </div>
//                 </ul>
//
//                 {/* Mobile hamburger */}
//                 <button className="ml-auto md:hidden rounded-lg hover:bg-white/10 p-1" onClick={() => setShowMenu((v) => !v)}>
//                     {showMenu ? <XMarkIcon className="h-6 w-6 text-white" /> : <Bars3Icon className="h-6 w-6 text-white" />}
//                 </button>
//             </div>
//
//             {/* Mobile menu */}
//             {showMenu && (
//                 <div className="md:hidden px-4 pb-4 glass rounded-t-3xl mx-2">
//                     <div className="flex items-center justify-between mb-3">
//                         <div className="flex items-center gap-2 flex-1">
//                             <input
//                                 type="text"
//                                 placeholder="Search..."
//                                 className="flex-1 px-4 py-2 rounded-lg bg-white/10 border border-white/15 text-white placeholder-white/60 focus:outline-none"
//                             />
//                             <button className="btn-ghost p-2">
//                                 <MagnifyingGlassIcon className="h-5 w-5" />
//                             </button>
//                         </div>
//                     </div>
//
//                     <ul className="flex flex-col gap-2">
//                         <Link to="/" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
//                             Home
//                         </Link>
//                         <Link to="/products" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
//                             Products
//                         </Link>
//                         {categories.map((cat) => (
//                             <button
//                                 key={cat}
//                                 onClick={() => handleCategoryClick(cat)}
//                                 className="text-left px-0 py-1 text-white/85 hover:text-white"
//                             >
//                                 {cat}
//                             </button>
//                         ))}
//                         <Link to="/cart" className="text-white/90 hover:text-white" onClick={handleMenuClick}>
//                             Cart
//                         </Link>
//                         <Link to="/profile" className="text-white/90 bg-gray-900 hover:text-white" onClick={handleMenuClick}>
//                             My Account
//                         </Link>
//                         <Link to="/orders" className="text-white/90 hover:text-white" onClick={handleMenuClick}>
//                             Orders
//                         </Link>
//                         <Link to="/about" className="text-white/90 hover:text-white" onClick={handleMenuClick}>
//                             About Us
//                         </Link>
//                         {isLoggedIn ? (
//                             <button onClick={handleLogout} className=" text-white/90 hover:text-red-100">
//                                 Logout
//                             </button>
//                         ) : (
//                             <Link to="/login" className="text-white/90 hover:text-white" onClick={handleMenuClick}>
//                                 Login
//                             </Link>
//                         )}
//                     </ul>
//                 </div>
//             )}
//         </nav>
//     );
// }

import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
    MagnifyingGlassIcon,
    ShoppingCartIcon,
    UserCircleIcon,
    XMarkIcon,
    Bars3Icon,
} from "@heroicons/react/24/outline";
import { SunIcon, MoonIcon } from "@heroicons/react/24/solid";
import { useCart } from "../context/CartContext";
import SearchBar from "./SearchBar";

export default function Navbar() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [showMenu, setShowMenu] = useState(false);
    const [catsOpen, setCatsOpen] = useState(false);
    const [theme, setTheme] = useState("light");
    const catsTimerRef = useRef(null);
    const menuRef = useRef(null);
    const navigate = useNavigate();
    const { getTotalItems } = useCart();

    useEffect(() => {
        const loggedIn = localStorage.getItem("isLoggedIn") === "true";
        setIsLoggedIn(loggedIn);
    }, []);

    // Load + apply theme on mount
    useEffect(() => {
        const saved = localStorage.getItem("theme") || "light";
        setTheme(saved);
        document.documentElement.setAttribute("data-theme", saved);
    }, []);

    // Handle clicks outside the user menu
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setShowMenu(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const toggleTheme = () => {
        const next = theme === "dark" ? "light" : "light";
        setTheme(next);
        localStorage.setItem("theme", next);
        document.documentElement.setAttribute("data-theme", next);
    };

    const openCats = () => {
        if (catsTimerRef.current) clearTimeout(catsTimerRef.current);
        setCatsOpen(true);
    };
    const closeCats = () => {
        if (catsTimerRef.current) clearTimeout(catsTimerRef.current);
        catsTimerRef.current = setTimeout(() => setCatsOpen(false), 120);
    };

    const handleLogout = () => {
        localStorage.clear();
        setIsLoggedIn(false);
        navigate("/login");
        window.location.reload();
    };

    const handleMenuClick = () => setShowMenu(false);
    const handleCategoryClick = (category) => {
        navigate(`/products?category=${encodeURIComponent(category)}`);
        setShowMenu(false);
    };

    // User menu handlers
    const handleUserMenuEnter = () => {
        setShowMenu(true);
    };

    const handleUserMenuLeave = () => {
        // Small delay to prevent accidental closure
        setTimeout(() => setShowMenu(false), 150);
    };

    const categories = ["Electronics", "Fashion", "Home", "Books", "Toys"];

    return (
        <nav className="nav-glossy">
            <div className="max-w-7xl mx-auto px-4 py-3 bg-black bg-opacity-80 backdrop-blur-md shadow-[0_0_10px_rgba(255,255,255,0.1)] border-b border-gray-800 flex items-center gap-4 text-white">
                {/* Brand */}
                <Link to="/" className="flex items-center gap-2 group">
                    <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] shadow-lg">
                        <img src="/favicon.svg" alt="Logo" className="h-full w-full object-cover rounded-lg" />
                    </div>
                    <span className="text-white font-extrabold tracking-tight text-lg group-hover:opacity-90">
            E‑Shopping Zone
          </span>
                </Link>

                {/* Search */}
                <div className="hidden md:flex items-center flex-1 mx-6">
                    <SearchBar />
                </div>

                {/* Desktop links/actions */}
                <ul className="ml-auto hidden md:flex gap-6 items-center">
                    <Link to="/" className="text-white hover:text-white link-underline">Home</Link>
                    <Link to="/products" className="text-white hover:text-white link-underline">Products</Link>

                    {/* Categories dropdown */}
                    <div className="relative" onMouseEnter={openCats} onMouseLeave={closeCats}>
                        <button className="text-white hover:text-white link-underline">Categories</button>
                        {catsOpen && (
                            <div className="absolute bg-gray-700 text-white  right-0 mt-3 w-44 rounded-2xl glass p-2 z-50">
                                {categories.map((cat) => (
                                    <button
                                        key={cat}
                                        onClick={() => handleCategoryClick(cat)}
                                        className="block w-full text-left px-3 py-2 rounded-lg hover:bg-gray-800 hover:text-white"
                                    >
                                        {cat}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/*Theme toggle */}
                    {/*<button*/}
                    {/*    aria-label="Toggle theme"*/}
                    {/*    onClick={toggleTheme}*/}
                    {/*    className="rounded-lg hover:bg-white/10 p-1 transition text-white"*/}
                    {/*    title={theme === "light" ? "Switch to light" : "Switch to dark"}*/}
                    {/*>*/}
                    {/*    {theme === "light" ? <SunIcon className="h-6 w-6" /> : <MoonIcon className="h-6 w-6" />}*/}
                    {/*</button>*/}

                    {/* Cart */}
                    <Link to="/cart" className="relative">
                        <ShoppingCartIcon className="h-6 w-6 text-white/90 hover:text-white transition" />
                        {getTotalItems() > 0 && (
                            <span className="absolute -top-2 -right-2 bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)] text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-lg">
                {getTotalItems()}
              </span>
                        )}
                    </Link>

                    {/* User menu - Enhanced with hover and click outside */}
                    <div className="relative" ref={menuRef}>
                        <button
                            onClick={() => setShowMenu(prev => !prev)}
                            onMouseEnter={handleUserMenuEnter}
                            className="rounded-lg hover:bg-white/10 p-1 transition flex items-center gap-1"
                        >
                            <UserCircleIcon className="h-8 w-8 text-white/90 hover:text-white" />
                            <svg
                                className={`w-3 h-3 text-white/70 transition-transform ${showMenu ? 'rotate-180' : ''}`}
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        {showMenu && (
                            <div
                                onMouseEnter={handleUserMenuEnter}
                                onMouseLeave={handleUserMenuLeave}
                                className="absolute bg-gray-700 right-0 mt-3 w-56 rounded-2xl glass p-2 z-50 animate-in slide-in-from-top-2 duration-200"
                            >
                                <Link
                                    to="/profile"
                                    className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white transition"
                                    onClick={handleMenuClick}
                                >
                                    My Account
                                </Link>
                                <Link
                                    to="/orders"
                                    className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white transition"
                                    onClick={handleMenuClick}
                                >
                                    Orders
                                </Link>
                                <Link
                                    to="/about"
                                    className="block px-3 py-2 rounded-lg text-white/90 hover:bg-white/70 hover:text-white transition"
                                    onClick={handleMenuClick}
                                >
                                    About Us
                                </Link>
                                <div className="border-t border-white/20 my-2"></div>
                                {isLoggedIn ? (
                                    <button
                                        onClick={handleLogout}
                                        className="block w-full text-left px-3 py-2 rounded-lg text-red-400 hover:bg-red-500/20 hover:text-red-300 transition"
                                    >
                                        Logout
                                    </button>
                                ) : (
                                    <Link
                                        to="/login"
                                        className="block px-3 py-2 rounded-lg text-blue-400 hover:bg-blue-500/20 hover:text-blue-300 transition"
                                        onClick={handleMenuClick}
                                    >
                                        Login
                                    </Link>
                                )}
                            </div>
                        )}
                    </div>
                </ul>

                {/* Mobile hamburger */}
                <button className="ml-auto md:hidden rounded-lg hover:bg-white/10 p-1" onClick={() => setShowMenu((v) => !v)}>
                    {showMenu ? <XMarkIcon className="h-6 w-6 text-white" /> : <Bars3Icon className="h-6 w-6 text-white" />}
                </button>
            </div>

            {/* Mobile menu */}
            {showMenu && (
                <div className="md:hidden px-4 pb-4 glass rounded-t-3xl mx-2">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2 flex-1">
                            <input
                                type="text"
                                placeholder="Search..."
                                className="flex-1 px-4 py-2 rounded-lg bg-white/10 border border-white/15 text-white placeholder-white/60 focus:outline-none"
                            />
                            <button className="btn-ghost p-2">
                                <MagnifyingGlassIcon className="h-5 w-5" />
                            </button>
                        </div>
                    </div>

                    <ul className="flex flex-col gap-2">
                        <Link to="/" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            Home
                        </Link>
                        <Link to="/products" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            Products
                        </Link>
                        <Link to="/cart" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            Cart
                        </Link>

                        <Link to={"/categories"} className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            Categories
                        </Link>
                        <p className="bg-black h-2 text-white ">---</p>
                        <Link to="/profile" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            My Account
                        </Link>
                        <Link to="/orders" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            Orders
                        </Link>
                        <Link to="/about" className="text-white/90 hover:text-white link-underline" onClick={handleMenuClick}>
                            About Us
                        </Link>
                        {isLoggedIn ? (
                            <button onClick={handleLogout} className="text-white/90 hover:text-red-100 transition">
                                Logout
                            </button>
                        ) : (
                            <Link to="/login" className="text-white/90 hover:text-white" onClick={handleMenuClick}>
                                Login
                            </Link>
                        )}
                    </ul>
                </div>
            )}
        </nav>
    );
}