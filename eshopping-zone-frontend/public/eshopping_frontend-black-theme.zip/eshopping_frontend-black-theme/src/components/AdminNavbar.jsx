import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { getAuthToken } from "../api/_auth";

export default function AdminNavbar() {
    const navigate = useNavigate();
    const token = getAuthToken();

    const handleLogout = () => {
        localStorage.clear();
        window.dispatchEvent(new Event("auth:changed"));
        window.dispatchEvent(new Event("auth:role-changed"));
        navigate("/login");
    };

    return (
        <nav className="bg-gray-900 text-white p-4 flex justify-between items-center shadow-md">
            <h1 className="text-xl text-blue-500 font-bold">Admin Panel</h1>
            <div className="flex gap-6 items-center">
                <ul className="text-white p-4 flex gap-6 justify-between items-center font-medium">
                    <Link to="/admin" className="hover:text-blue-400">Dashboard</Link>
                    <li
                        className="hover:text-yellow-300 cursor-pointer"
                        onClick={() => navigate("/admin/products")}
                    >
                        Products
                    </li>
                    <li
                        className="hover:text-yellow-300 cursor-pointer"
                        onClick={() => navigate("/admin/users")}
                    >
                        Users
                    </li>
                    <li
                        className="hover:text-yellow-300 cursor-pointer"
                        onClick={() => navigate("/admin/settings")}
                    >
                        Settings
                    </li>
                    <li
                        className="hover:text-yellow-300 cursor-pointer"
                        onClick={() => navigate("/admin/order")}
                    >
                        Orders
                    </li>

                {token ? (
                    <button onClick={handleLogout} className="hover:text-red-400">Logout</button>
                ) : (
                    <Link to="/login" className="hover:text-green-400">Login</Link>
                )}
                </ul>
            </div>
        </nav>
    );
}