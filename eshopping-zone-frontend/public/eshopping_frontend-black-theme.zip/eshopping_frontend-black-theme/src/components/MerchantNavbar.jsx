import { Link, useNavigate } from "react-router-dom";
import React from "react";

export default function MerchantNavbar() {
    const navigate = useNavigate();

    const logout = () => {
        // Clear auth data and notify app to update role-aware UI
        ["token", "jwt", "jwtToken", "role"].forEach((k) => {
            localStorage.removeItem(k);
            sessionStorage.removeItem(k);
        });
        window.dispatchEvent(new Event("auth:role-changed"));
        navigate("/login");
    };

    return (
    <nav className="bg-gray-900 text-white p-4 flex justify-between items-center shadow-md">
        <h1 className="text-xl text-blue-500 font-bold">Merchant Panel</h1>
        <div className="flex gap-6 items-center">
            <ul className="text-white p-4 flex gap-6 justify-between items-center font-medium">
                <Link to="/merchant" className="hover:text-blue-400">Dashboard</Link>
                <li
                    className="hover:text-yellow-300 cursor-pointer"
                    onClick={() => navigate("/merchant/products")}
                >
                    Products
                </li>
                <li
                    className="hover:text-yellow-300 cursor-pointer"
                    onClick={() => navigate("/profile")}
                >
                    Profile
                </li>
                <li
                    className="hover:text-yellow-300 cursor-pointer"
                    onClick={() => navigate("/merchant/orders")}
                >
                    Orders
                </li>
                <li
                    className="hover:text-yellow-300 cursor-pointer"
                    onClick={() => navigate("/merchant/notifications")}
                >
                    Notifications
                </li>
                <button onClick={logout} style={{ marginLeft: "auto" }}>Logout</button>
            </ul>
        </div>
    </nav>
    );
}